- Créer un dépôt Github => OK
- Créer une mini-config 11ty => OK
- Créer une Github action pour générer et publier le site automatiquement :
   - manuel
   - automatique dès qu'un fichier est mis à jour
- Intégrer le framing (en réutilisant frame.js du projet SAPA + la spec de framing SAPA spa-skos-framing.json
- Gestion du multilingue en/fr (+ es ?) :
   - Gestion des fichiers de libellés RiC-O dans chaque langue
   - Gestion des libellés statiques du site dans chaque langue
- Générer 1 page par ConceptScheme
- Gérer la publication du site avec Github pages




##############################################
PS C:\Users\thoma\Documents\GitHub\garance> ssh-keygen -t rsa -b 4096 -f gh-pages -N "sparna2024#AN_!pr"                                              
Generating public/private rsa key pair.
Your identification has been saved in gh-pages
Your public key has been saved in gh-pages.pub
The key fingerprint is:
SHA256:Ex4sGwxeHhiQWn8m5SW6nfy2c3uSxqh8wUYEby3vmyY thoma@LAPTOP-71N0TO55
The key's randomart image is:
+---[RSA 4096]----+
|  .ooo+.         |
|  o..=o+o.       |
| o ..+=+B .      |
|.   + +*.=       |
|     B.+S .      |
|    . + +o       |
|       o +..     |
|     .  E Bo.    |
|      o+.B++     |
+----[SHA256]-----+