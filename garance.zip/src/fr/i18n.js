module.exports = {
  title: {
    fr: "Graphe Archivistique pour la Recherche, l'Accès et la Navigation des Connaissances Enhancées.",
  },
  garance: { fr: "Garance" },
};