module.exports = [
  {
    label: 'FR',
    code: 'fr'
  },
  {
    label: 'EN',
    code: 'en'
  }
];