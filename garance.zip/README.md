# GARANCE

*G*raphe *A*rchivistique pour la *R*echerche, l'*A*ccès et la *N*avigation des *C*onnaissances *E*nhancées

## Liens

Dépôt actuel des données des référentiels : https://github.com/ArchivesNationalesFR/Referentiels

- Agents
  - Personnes
  - CorporateBody
  - Producteurs d'archives (avec leurs relations)
- Lieux
  - Communes
  - Départements
  - Voies de Paris
  - Quartiers de Paris
  - etc.
- Concepts
  - Types d'organisation
  - Types de document
  - etc.
