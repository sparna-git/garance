module.exports = {
  title: {en: "Archival Graph for Research, Knowledge Access and Navigation Enhancer."},
  garance: { en: "Madder" },
};