module.exports = {
  title: {
    fr: "Graphe Archivistique pour la Recherche, l'Accès et la Navigation des Connaissances Enhancées.",
    en: "Archival Graph for Research, Knowledge Access and Navigation Enhancer."
  },
  garance: {
    fr: "Garance",
    en: "Madder"
  },
};